package com.example.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MyCv {
    private String name;
    private int age;
    private String address;
    private String email;
    private String education;
    private String skills;
    private String experience;
}
