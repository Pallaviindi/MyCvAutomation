package com.example.test;

import org.testng.annotations.*;
import static org.assertj.core.api.Assertions.*;
import com.example.model.MyCv;

public class MyCvTest {

    private MyCv myCv;

    @BeforeClass
    public void setUp() {
        myCv = new MyCv(
                "Pallavi G Indi",
                22,
                "Bijapur, India",
                "indipallavi@gmail.com",
                "B.Tech in Electrical And Electronics Engineering",
                "Java, Selenium, Maven, TestNG, API Testing",
                "Software Testing Intern at DataArt"
        );
    }

    @Test
    public void printCV() {
        System.out.println("====================================");
        System.out.println("         MY PROFESSIONAL CV         ");
        System.out.println("====================================");
        System.out.println("Name       : " + myCv.getName());
        System.out.println("Age        : " + myCv.getAge());
        System.out.println("Address    : " + myCv.getAddress());
        System.out.println("Email      : " + myCv.getEmail());
        System.out.println("Education  : " + myCv.getEducation());
        System.out.println("Skills     : " + myCv.getSkills());
        System.out.println("Experience : " + myCv.getExperience());
        System.out.println("====================================");
    }

    @AfterClass
    public void validateCVFields() {
        assertThat(myCv.getName()).isNotEmpty();
        assertThat(myCv.getEmail()).contains("@");
        assertThat(myCv.getSkills()).isNotEmpty();
        assertThat(myCv.getExperience()).isNotEmpty();
        System.out.println("✅ All CV fields validated successfully!");
    }
}
